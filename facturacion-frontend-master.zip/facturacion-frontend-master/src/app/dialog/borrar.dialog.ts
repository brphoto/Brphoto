/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import { Component } from '@angular/core';


@Component({
    selector: "borrar-dialog",
    templateUrl: "./borrar-dialog.html"
})

export class BorrarDialog {}