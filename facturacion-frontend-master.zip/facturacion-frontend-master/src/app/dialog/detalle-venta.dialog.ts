import { Component } from '@angular/core';


@Component({
  selector: 'producto-new-dialog',
  templateUrl: './producto-new-dialog.html'
})

export class ProductoNewDialog {}


