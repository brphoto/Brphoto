export class Pedido {
    id: number;
    clienteId: number;
    nombre: string;
}